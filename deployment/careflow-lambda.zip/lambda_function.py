import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent / 'backend'))
from backend.lambda_function import lambda_handler
